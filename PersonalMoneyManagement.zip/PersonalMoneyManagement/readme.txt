Author: Ray Wong (wongyatho2@gmail.com)

Before you start this Django project:
You need to install following development tools:
1. Python version 3.8.0 or above


2. Python(Web framwork) - Django version 3.0
   pip install Django==3.0

3. mysqlclient connector for Python
   pip install mysqlclient
   
4. MySQL Community Server - 8.0.18GA or above

5. Creating database and table by executing create_db.sql on MySql query 
   
6. Please re-generate SECRET_KEY on settings.py
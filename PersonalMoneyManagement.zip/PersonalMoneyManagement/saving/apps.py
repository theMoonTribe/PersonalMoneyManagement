from django.apps import AppConfig


class SavingConfig(AppConfig):
    name = 'saving'
